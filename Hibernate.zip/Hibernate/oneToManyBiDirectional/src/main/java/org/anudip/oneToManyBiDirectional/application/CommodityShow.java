package org.anudip.oneToManyBiDirectional.application;

import java.util.Collections;
import java.util.List;

import org.anudip.oneToManyBiDirectional.bean.Commodity;
import org.anudip.oneToManyBiDirectional.dao.DatabaseHandler;
import org.hibernate.Query;
import org.hibernate.Session;

public class CommodityShow {

	public static void main(String[] args) throws Exception{
		DatabaseHandler dbHandler=DatabaseHandler.getDatabaseHandler();
   	    Session session=dbHandler.createSession();
   	 String queryStatement="from Commodity";
   	Query<Commodity> query=session.createQuery(queryStatement);
    List<Commodity> commodityList=query.list();
    
    Collections.reverse(commodityList);
    
    commodityList.forEach(commodity->System.out.println(commodity));
	   	 session.close();
}
}
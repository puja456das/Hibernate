package org.anudip.HibernatelabApplication2.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.OneToOne;
import javax.persistence.CascadeType;
@Entity
@Table(name = "students")
public class Student {
    @Id
    @Column(name = "roll_number")
    private String rollNumber;

    @Column(name = "student_name")
    private String studentName;

    private String semester;

    @OneToOne(mappedBy = "student", cascade = CascadeType.ALL)
    private Result result;
    //Constructors
	public Student() {
		super();
		
	}
	public Student(String rollNumber, String studentName, String semester) {
		super();
		this.rollNumber = rollNumber;
		this.studentName = studentName;
		this.semester = semester;
	}
	  //Getter and setter method
	public String getRollNumber() {
		return rollNumber;
	}
	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getSemester() {
		return semester;
	}
	public void setSemester(String semester) {
		this.semester = semester;
	}
	@Override
	public String toString() {
        return String.format("%-5s %-20s %-5s %",rollNumber,studentName,semester);
	}
	

}


package org.anudip.HibernatelabApplication2.application;

import org.anudip.HibernatelabApplication2.bean.Result;
//Declare  class ResultService  with member function
public class ResultService {

    public static String gradeCalculation(Result result) {
        double totalMarks = result.getHalfYearlyTotal() + result.getAnnualTotal();
        double percentage = (totalMarks / 1000) * 100;

        if (percentage >= 90) {
            return "E";
        } else if (percentage >= 75) {
            return "V";
        } else if (percentage >= 60) {
            return "G";
        } else if (percentage >= 45) {
            return "P";
        } else {
            return "F";
        }
    }
}

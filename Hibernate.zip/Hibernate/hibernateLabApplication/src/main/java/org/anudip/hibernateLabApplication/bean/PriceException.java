package org.anudip.hibernateLabApplication.bean;

import javax.persistence.*;
public class PriceException extends RuntimeException {
    public PriceException(String message) {
        super(message);
    }
}
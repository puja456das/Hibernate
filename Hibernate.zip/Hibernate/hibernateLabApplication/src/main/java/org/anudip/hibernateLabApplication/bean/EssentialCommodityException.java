package org.anudip.hibernateLabApplication.bean;
import javax.persistence.*;
public class EssentialCommodityException extends RuntimeException {
    public EssentialCommodityException(String message) {
        super(message);
    }
}